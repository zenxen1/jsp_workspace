// JavaScript Document
function openWin(page,w,h){
	option="width="+w+",height="+h+",scrollbars=no,status=no,menubar=no,scrollbars=no"
	window.open(page,"pop",option);
}